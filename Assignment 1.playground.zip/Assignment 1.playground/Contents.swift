//: Playground - noun: a place where people can play
var budget: Float = 50.0
let rest_list: [String] = ["Salty Sow", "Kerby Lane", "Milto's", "Trudy's", "Madam Mam's", "Vert's", "Teji's", "Home"]
let rest_costs: [String: Float] = ["Salty Sow": 30, "Kerby Lane": 10.99, "Milto's": 10.5, "Trudy's": 11.7,
                                  "Madam Mam's": 13.99, "Vert's": 7.99, "Teji's": 8.99, "Home": 0]
let rest_tips: [String: Float] = ["Salty Sow": 1.2, "Kerby Lane": 1.18, "Milto's": 1.18, "Trudy's": 1.18,
                                  "Madam Mam's": 1.18, "Vert's": 1.15, "Teji's": 1.15, "Home": 1.0]
let tx_tax: Float = 1.0825
let weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

for i in 1...14 {
    
    print("Week \(i)")
    for j in 0...6 {
        
        var current_rand = Int(arc4random_uniform(UInt32(rest_list.count)))
        var current_restaurant:String = rest_list[current_rand]
        var current_cost = (rest_costs[current_restaurant])! * (rest_tips[current_restaurant])! * tx_tax
        
        while current_cost > budget {
            
            current_rand = Int(arc4random_uniform(UInt32(rest_list.count)))
            current_restaurant = rest_list[current_rand]
            current_cost = (rest_costs[current_restaurant])! * (rest_tips[current_restaurant])! * tx_tax
            
        }
 
        budget -= current_cost
        print("\(weekdays[j]) meal: \(current_restaurant), budget now \(budget)")
    
    }
    budget += 50
    print("\n")
}
