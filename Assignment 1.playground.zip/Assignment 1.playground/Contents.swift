//: Playground - noun: a place where people can play

import UIKit

var budget = 50
let rest_list = ["Salty Sow", "Kerby Lane", "Milto's", "Trudy's",
                 "Madam Mam's", "Vert's", "Teji's", "Home"]
let rest_costs = ["Salty Sow": 30, "Kerby Lane": 10.99, "Milto's": 10.5, "Trudy's": 11.7,
                  "Madam Mam's": 13.99, "Vert's": 7.99, "Teji's": 8.99, "Home": 0]
let rest_tips = ["Salty Sow": 1.2, "Kerby Lane": 1.18, "Milto's": 1.18, "Trudy's": 1.18,
                "Madam Mam's": 1.18, "Vert's": 1.15, "Teji's": 1.15, "Home": 1.0]
let tx_tax = 1.0825
