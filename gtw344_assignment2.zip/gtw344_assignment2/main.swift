//
//  main.swift
//  gtw344_assignment2
//
//  Created by Don Hogan on 2/7/19.
//  Copyright © 2019 Garrett Willis. All rights reserved.
//

import Foundation

var racetracks = ["Circuit of the Americas", "Nurburgring", "Circuit de Spa-Francorchamps",
                  "Circuit de Monte Carlo", "Yas Marina", "Circuit de Catalunya"]
var honda = Automobile(newMake:"Honda", newModel:"Accord")
var toyota = Automobile(newMake:"Toyota", newModel:"Corolla")
var mini = Automobile(newMake:"MINI", newModel:"Cooper")
var carList = [honda, toyota, mini]
honda.pickTrack(trackList: &racetracks)
var leadCar = honda.getLeadCar()
var roundNum = 0

for _ in 0..<10 {
    
    roundNum += 1
    for car in carList {
        car.increaseSpeed()
        car.addDistance()
        //print("\(car.description()) \n \(car.getDistance()) miles traveled")
    }
    
    if honda.getLeadTie() == true {print("Two or more cars are in the lead.")}
    else {
        leadCar = honda.getLeadCar()
        print("\(leadCar.getMake()) \(leadCar.getModel()) is in the lead.")
    }
    
    //print("Lead distance : \(honda.getLeadDistance()) \n Lead tie? : \(honda.getLeadTie())s")
    print("ROUND \(roundNum) OVER\n")
}

for car in carList {print(car.description())}
if honda.getLeadTie() == false {
    leadCar = honda.getLeadCar()
    print("\(leadCar.getMake()) \(leadCar.getModel()) won the race on \(leadCar.getCurrentTrack())!")
}
else {print("There was a tie!")}
