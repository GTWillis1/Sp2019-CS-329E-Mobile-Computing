//
//  Automobile.swift
//  gtw344_assignment2
//
//  Created by Garrett Willis on 2/7/19.
//  Copyright © 2019 Garrett Willis. All rights reserved.
//

class Automobile {

    static var currentTrack:String = "Circuit of the Americas"
    static var leadDistance:Float = 0
    static var leadCar:Automobile = Automobile()
    static var leadTie:Bool = false
    var make:String
    var model:String
    var speed:Int
    var distance:Float
    
    init(newMake:String = "", newModel:String = "", newSpeed:Int = 0, newDistance:Float = 0) {
        self.make = newMake
        self.model = newModel
        self.speed = newSpeed
        self.distance = newDistance
    }
    
    func pickTrack(trackList:inout [String]) {
        Automobile.currentTrack = trackList[Int.random(in: 0..<trackList.count)]
    }
    
    func getMake() -> String {return self.make}
    func setMake(newMake:String) {self.make = newMake}
    
    func getModel() -> String {return self.model}
    func setModel(newModel:String) {self.model = newModel}
    
    func getSpeed() -> Int {return self.speed}
    func setSpeed(newSpeed:Int) {self.speed = newSpeed}
    
    func getCurrentTrack() -> String {return Automobile.currentTrack}
    func setCurrentTrack(trackList:inout [String], trackIndex:Int) {
        Automobile.currentTrack = trackList[trackIndex]
    }
    
    func getDistance() -> Float {return self.distance}
    func addDistance() {
        self.distance += Float(self.speed) * (5/3600) //Rounds = 5sec, speed = mph -> hr = sec/3600
        if self.distance > Automobile.leadDistance {
            Automobile.leadDistance = self.distance
            Automobile.leadCar = self
            Automobile.leadTie = false
        } else if self.distance == Automobile.leadDistance {
            Automobile.leadTie = true
        } else {Automobile.leadTie = false}
    }
    
    func getLeadDistance() -> Float {return Automobile.leadDistance}
    func getLeadCar() -> Automobile {return Automobile.leadCar}
    func getLeadTie() -> Bool {return Automobile.leadTie}
    
    func description() -> String {
        return "Make: \(self.make), Model: \(self.model), Speed: \(self.speed)"
    }
    
    func increaseSpeed() {
        self.speed += Int.random(in: 5..<21)
    }
}
